INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (2, 'John Yalis', '1990-03-17', 'Los Angeles, CA');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (3, 'Mary Walker', '1991-11-16', 'Paradise, NV');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (4, 'Michael Simpson', '1983-12-09', 'New York, NY');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (5, 'Lucy Scotch', '1975-11-23', 'Seattle, WA');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (6, 'Calvin Anderson', '1972-07-18', 'Ohio, OH');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (7, 'Kate Winston', '1985-01-01', 'Santa Maria, CA');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (8, 'Judith Taylor', '1972-02-25', 'Boulder, CO');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (9, 'Joshua Lee', '1969-04-13', 'Richardson, TX');
INSERT INTO contacts.person (id, complete_name, birth_date, place_of_birth) VALUES (10, 'Vander Wilson', '1988-12-26', 'Burbank, CA');
